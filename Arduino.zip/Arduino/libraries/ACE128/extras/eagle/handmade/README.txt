These are some old eagle files from my original Dalek prototype boards. 

These boards were single sided, iron-on, etched and hand-drilled.

I don't think I ever made the PCF8574 board, and the BRD file for the MCP23008 is missing. 

I think the schematics are correct.

So these are included for interest only, I'm not guaranteeing they work. 