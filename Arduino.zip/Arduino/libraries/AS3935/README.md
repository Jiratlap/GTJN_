# AS3935 lightning sensor library

Arduino library to support Austrian Microsystems AS3935 lightning
sensor using the I2C interface. For I2C support the SoftWire software
bit-banging Arduino library is used
(https://github.com/stevemarple/SoftWire).

## License
Released under the GNU Lesser General Public License, version 2.1. See
LICENSE.txt for details.



